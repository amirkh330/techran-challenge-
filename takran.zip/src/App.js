import React from "react";
import LayoutApp from "./libs/Layout/LayoutApp";
import Routes from "./libs/Component/Routes/Routes";

export default function App() {
  return (
    <>
      <LayoutApp>
        <Routes />
      </LayoutApp>
    </>
  );
}
